function toggleMenu( ) {
    var navList = document.getElementById('navList');
    navList.classList.toggle('show');
}